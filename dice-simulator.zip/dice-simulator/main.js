// Dice Simulator

// Event Listeners
document.getElementById('play-btn').addEventListener('click', youVsHouse)

document.getElementById('purchase-btn').addEventListener('click', yourPurchase)

let house_roll = Math.random() * 6;
house_roll = Math.round(house_roll);
    
let your_roll = Math.random() * 6;
your_roll = Math.round(your_roll);

let funds = Number(document.getElementById('funds').innerHTML);

//Event Function
function youVsHouse() {
    //Setting variables...
    let house_roll = Math.random() * 6;
    house_roll = Math.round(house_roll);
    
    let your_roll = Math.random() * 6;
    your_roll = Math.round(your_roll);

    let funds = Number(document.getElementById('funds').innerHTML);
    let bet = Number(document.getElementById('bet-input').value);
    
    // If statement for who wins
    if (house_roll > your_roll) {
        console.log('House won!');
        funds = funds - bet;
        document.getElementById('funds').innerHTML = funds;
    
    } else if (house_roll < your_roll) {
        console.log('You won!');
        funds = funds + bet;
        document.getElementById('funds').innerHTML = funds;
        funds == funds;

    }


    // Picture display
    if (house_roll == 1) {
        document.getElementById('house-die').src = 'images/1.png';
        console.log('1');

    } else if (house_roll == 2) {
        document.getElementById('house-die').src = 'images/2.png';
        console.log('2');

    } else if (house_roll == 3) {
        document.getElementById('house-die').src = 'images/3.png';
        console.log('3');

    } else if (house_roll == 4) {
        document.getElementById('house-die').src = 'images/4.png';
        console.log('4');

    } else if (house_roll == 5) {
        document.getElementById('house-die').src = 'images/5.png';
        console.log('5');

    } else if (house_roll == 6) {
        document.getElementById('house-die').src = 'images/6.png';
        console.log('6');

    }
    
    if (your_roll == 1) {
        document.getElementById('player-die').src = 'images/1.png';

    } else if (your_roll == 2) {
        document.getElementById('player-die').src = 'images/2.png';

    } else if (your_roll == 3) {
        document.getElementById('player-die').src = 'images/3.png';

    } else if (your_roll == 4) {
        document.getElementById('player-die').src = 'images/4.png';

    } else if (your_roll == 5) {
        document.getElementById('player-die').src = 'images/5.png';

    } else if (your_roll == 6) {
        document.getElementById('player-die').src = 'images/6.png';

    }

    if (funds < 0 && bet > 1) {
        document.getElementById('funds').innerHTML = "0"
    }
}

function yourPurchase() {
    // Variables
    let funds = Number(document.getElementById('funds').innerHTML);

    let num = Math.random()

    //Prizes
    if (funds > 5000){
        if(num >= 0 && num < 0.25) {
            document.getElementById('loot').innerHTML = "<img src = 'images/car.png'>"
        } else if(num >= 0.25 && num < 0.5){
            document.getElementById('loot').innerHTML = "<img src = 'images/boat.png'>"
        } else if(num >= 0.5 && num < 0.75){
            document.getElementById('loot').innerHTML = "<img src = 'images/house.png'>"
        } else if(num >= 0.75 && num <= 1){
            document.getElementById('loot').innerHTML = "<img src = 'images/motorcycle.jpg'>"
        }
    }

    if (funds < 5000 && funds >= 1000) {
        if(num >= 0 && num < 0.33){
            document.getElementById('loot').innerHTML = "<img src = 'images/trip.jpg'>"
        } else if(num >= 0.33 && num < 0.67){
            document.getElementById('loot').innerHTML = "<img src = 'images/ring.png'>"
        } else if(num >= 0.67 && num < 1){
            document.getElementById('loot').innerHTML = "<img src = 'images/bike.jpg'>"
        }
    }

    if (funds < 1000) {
        document.getElementById('loot').innerHTML = "<img src = 'images/socks.png'>";
    }

    if (funds <= 0) {
        document.getElementById('loot').innerHTML = "<img src = 'images/no.png'>";
    }
}


