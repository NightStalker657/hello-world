// Mario Kart
'use strict';

document.getElementById('click').addEventListener('click', imgClick)


function imgClick() {
    console.log('Mario Kart');
    
    let rand_num = Math.random();

    if (rand_num <= 0.25) {
        console.log('Banana')
        document.getElementById('img').innerHTML += '<img src="images/banana.jpeg">';

    } else if (rand_num > 0.25 && rand_num <= 0.5) {
        console.log('Green Shell')
        document.getElementById('img').innerHTML += '<img src="images/shell.png">';


    } else if (rand_num > 0.5 && rand_num <= 0.65) {
        console.log('Star')
        document.getElementById('img').innerHTML += '<img src="images/star.png">';


    } else if (rand_num > 0.65 && rand_num <= 0.8) {
        console.log('Golden Mushroom')
        document.getElementById('img').innerHTML += '<img src="images/mushroom.png">';


    } else if (rand_num > 0.8 && rand_num <= 1) {
        console.log('Bullet Bill')
        document.getElementById('img').innerHTML += '<img src="images/Bullet_Bill.png">';


    }
}